# -*- coding: utf-8 -*-

from . import purchase_approval_config
from . import purchase_approval_line
from . import res_config_setting
from . import inherit_purchase_order
from . import approval_info
from . import rejection_wizard